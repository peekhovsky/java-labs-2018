package com.company;

public abstract class Figure {
    public abstract void show();
    public abstract Double getPerimeter();
}
